﻿using Eu_Nite.Shared;
using Eu_Nite.Shared.Helpers;
using Eu_Nite.Shared.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace Eu_Nite.Server.Controllers
{
    [Route("eu-nite/")]
    public class Eu_NiteController : Controller
    {
        private IHttpClientFactory _httpClient;

        public Eu_NiteController(IHttpClientFactory httpClient)
        {
            _httpClient = httpClient;
        }

        [HttpGet("[action]")]
        public async Task<UserModel> Current_User()
        {

            var response = await HttpResultSet(HttpMethod.Get, Constants.current_user_endpoint, HttpContext.Session.GetString(Constants.session_key));

            if (response != null)
            {
                UserModel current_User = new UserModel();
                JObject jsonObject = JObject.Parse(JsonConvert.SerializeObject(response.Content.ReadAsStringAsync()));
                current_User = JsonConvert.DeserializeObject<UserModel>(jsonObject["Result"].ToString());
                return current_User;
            }
            return null;
        }

        [HttpGet("[action]")]
        public async Task<List<EmployeeModel>> Employees()
        {
            var response = await HttpResultSet(HttpMethod.Get, Constants.employee_endpoint, HttpContext.Session.GetString(Constants.session_key));

            if (response != null)
            {
                List<EmployeeModel> employees = new List<EmployeeModel>();
                JObject jsonObject = JObject.Parse(JsonConvert.SerializeObject(response.Content.ReadAsStringAsync()));
                employees = JsonConvert.DeserializeObject<List<EmployeeModel>>(jsonObject["Result"].ToString());

                return employees;
            }
            return null;
        }

        [HttpGet("[action]")]
        public async Task<ProfileModel> Profile()
        {
            var response = await HttpResultSet(HttpMethod.Get, Constants.profile_endpoint, HttpContext.Session.GetString(Constants.session_key));

            if (response != null)
            {
                ProfileModel user_profile = new ProfileModel();

                JObject jsonObject = JObject.Parse(JsonConvert.SerializeObject(response.Content.ReadAsStringAsync()));
                user_profile = JsonConvert.DeserializeObject<ProfileModel>(jsonObject["Result"].ToString());
                return user_profile;
            }
            return null;
        }

        [HttpGet("[action]")]
        public async Task<List<ReviewModel>> Reviews()
        {
            var response = await HttpResultSet(HttpMethod.Get, Constants.review_endpoint, HttpContext.Session.GetString(Constants.session_key));

            if (response != null)
            {
                List<ReviewModel> reviews = new List<ReviewModel>();
                JObject jsonObject = JObject.Parse(JsonConvert.SerializeObject(response.Content.ReadAsStringAsync()));
                reviews = JsonConvert.DeserializeObject<List<ReviewModel>>(jsonObject["Result"].ToString());
                return reviews;
            }
            return null;
        }

        [HttpGet("[action]")]
        public async Task<List<CustomerModel>> Customers()
        {
            var response = await HttpResultSet(HttpMethod.Get, Constants.customers_endpoint, HttpContext.Session.GetString(Constants.session_key));

            if (response != null)
            {
                List<CustomerModel> customers = new List<CustomerModel>();
                JObject jsonObject = JObject.Parse(JsonConvert.SerializeObject(response.Content.ReadAsStringAsync()));
                customers = JsonConvert.DeserializeObject<List<CustomerModel>>(jsonObject["Result"].ToString());
                return customers;
            }
            return null;
        }
        [HttpGet("[action]")]
        public async Task<List<LeaveModel>> Leave_Details()
        {
            var response = await HttpResultSet(HttpMethod.Get, Constants.leave_endpoint, HttpContext.Session.GetString(Constants.session_key));

            if (response != null)
            {
                List<LeaveModel> leaveDetails = new List<LeaveModel>();
                JObject jsonObject = JObject.Parse(JsonConvert.SerializeObject(response.Content.ReadAsStringAsync()));
                leaveDetails = JsonConvert.DeserializeObject<List<LeaveModel>>(jsonObject["Result"].ToString());
                return leaveDetails;
            }
            return null;
        }

        public async Task<HttpResponseMessage> HttpResultSet(HttpMethod httpMethod, string requestUrl, string token)
        {
            var httpRequest = new HttpRequestMessage(httpMethod, requestUrl);
            var client = _httpClient.CreateClient();
            client.BaseAddress = new Uri(Constants.base_url);
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Token", token);

            HttpResponseMessage response = null;

            try
            {
                if (token.Equals(string.Empty))
                {
                    return null;
                }
                response = await client.SendAsync(httpRequest);
            }
            catch (Exception e)
            {
                HttpResponseMessage errorMessage = new HttpResponseMessage();
                errorMessage.StatusCode = HttpStatusCode.InternalServerError;
                errorMessage.Content = new StringContent(e.ToString());

                return errorMessage;
            }

            if (response.IsSuccessStatusCode)
            {
                return response;
            }
            return null;
        }
    }
}
