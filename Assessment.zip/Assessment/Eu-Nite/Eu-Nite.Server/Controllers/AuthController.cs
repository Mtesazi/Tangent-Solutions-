﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Eu_Nite.Shared.Models;
using System.Net.Http;
using Eu_Nite.Shared.Helpers;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net;

namespace Eu_Nite.Server.Controllers
{

    [Route("eu-nite/[controller]")]
    public class AuthController : ControllerBase
    {
        private IHttpClientFactory _httpClient;
        public AuthController(IHttpClientFactory httpClient)
        {
            _httpClient = httpClient;
        }
        [HttpPost("[action]")]
        public async Task<ActionResult> Login([FromForm]LoginModel login_model)
        {

            var auth_client = _httpClient.CreateClient();
            auth_client.BaseAddress = new Uri(Constants.base_url);

            var login_credentials = new Dictionary<string, string>
            {
                {"username",login_model.UserName },
                {"password",login_model.Password }
            };

            var form_data = new FormUrlEncodedContent(login_credentials);

            var http_response = await auth_client.PostAsync(Constants.auth_endpoint, form_data);


            if (http_response.IsSuccessStatusCode)
            {

                JObject jsonResult = JObject.Parse(JsonConvert.SerializeObject(http_response.Content.ReadAsStringAsync()));

                //save the token value into a session which is going to be used in the app controller
                TokenModel tangent_Token = new TokenModel();

                tangent_Token = JsonConvert.DeserializeObject<TokenModel>(jsonResult["Result"].ToString());
                HttpContext.Session.SetString(Constants.session_key, tangent_Token.Token);


                return Ok();
            }
            return Unauthorized();
        }

        [HttpPost("[action]")]
        public async Task<ActionResult> Logout()
        {
            HttpContext.Session.SetString(Constants.session_key, String.Empty);

            return Ok();
        }
    }
}