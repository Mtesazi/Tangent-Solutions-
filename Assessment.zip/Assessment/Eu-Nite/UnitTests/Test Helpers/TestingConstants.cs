﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTests.Test_Helpers
{
    public class TestingConstants
    {
        public static string token_value = "2a3d1af2f3f6d1cddaa3012c1c465fcbdffa3678";
        public static string invalid_token_value = "12345678910111223";
    }
}
