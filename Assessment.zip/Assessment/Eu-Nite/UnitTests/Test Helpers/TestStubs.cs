﻿using Eu_Nite.Shared.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTests.Test_Helpers
{
    public class TestStubs
    {
        public static readonly UserModel User = new UserModel
        {
            Id = 100,
            UserName = "superman",
            Email = "super.man@whatever.com",
            First_Name = "Clark",
            Last_Name = "Kent",
            Is_Active = true,
            Is_Staff = true,
            Is_SuperUser = false
        };

        public static readonly List<EmployeeModel> Employees = new List<EmployeeModel>
        {
            new EmployeeModel
            {
                User = new UserModel {Id = 100, UserName = "superman", Email = "super.man@whatever.com", First_Name = "Clark",Last_Name="Kent",
                Is_Active= true, Is_Staff = true, Is_SuperUser = false},
                Position = new PositionModel {Id=1, Level = "senior", Name="superhero", Sort = 0},
                Phone_Number = "12345678901",
                Email = "super.man@whaterver.com", Github_User = "super.man", Birth_Date = "1243-1-1",
                Gender = "M",Race = "W", Years_Worked = 100, Age = 45,Days_To_Birthday = 12
            },
            new EmployeeModel
            {
                User = new UserModel {Id = 15, UserName = "storm", Email = "storm.xmen@whatever.com", First_Name = "Storm",Last_Name="White",
                Is_Active= true, Is_Staff = true, Is_SuperUser = false},
                Position = new PositionModel {Id=3, Level = "senior", Name="superhero", Sort = 1},
                Phone_Number = "2468101214",
                Email = "storm.xmen@whaterver.com", Github_User = "storm@xmen", Birth_Date = "1992-1-1",
                Gender = "F",Race = "B", Years_Worked = 100, Age = 45,Days_To_Birthday = 12
            }
        };

        public static readonly ProfileModel UserProfile = new ProfileModel
        {
            Id = User.Id,
            User = User,
            Position = new PositionModel { Id = 1, Level = "Senior", Name = "superhero", Sort = 0 },
            Employee_Next_Of_Kin = new List<NextOfKinModel>
            {
                new NextOfKinModel
                {
                    Id = 2,
                    Name = "mommy",
                    Relationship = "mother",
                    Email = null,
                    Phone_Number = "9999933333",
                    Employee = User.Id,
                    Physical_Address = "22 Culross Road Bryanston Sandton"
                }
            },
            Id_Number = "89089809809809080980",
            Phone_Number = "12345678901",
            Physical_Address = "43243 Daveyton 1520 Benoni",
            Tax_Number = "1357912",
            Email = "super.kent@superheros.com",
            Personal_Email = User.Email,
            Github_User = "super.man",
            Birth_Date = "1243-1-1",
            Start_Date = "2010-10-1",
            End_Date = null,
            Id_Document = null,
            Visa_Document = null,
            Is_Employed = true,
            Is_Foreigner = false,
            Gender = "M",
            Race = "W",
            Years_Worked = 100,
            Age = 45,
            Next_Review = "2019-10-12",
            Days_To_Birthday = 12,
            Leave_Remaining = "35"

        };

        public static readonly List<ReviewModel> Review = new List<ReviewModel>
        {
            new ReviewModel
            {
                Id = 21,
                Date = "2019-3-12",
                Employee = 100,
                Salary = "1200000",
                Position = 1,
                Type = "P"
            },
            new ReviewModel
            {
                Id = 22,
                Date = "2019-9-12",
                Employee = 100,
                Salary = "1200000",
                Position = 1,
                Type = "A"
            }
        };

        public static readonly List<CustomerModel> Customers = new List<CustomerModel>
        {
            new CustomerModel
            {
                Id = 1,
                Code = "cust123",
                Name = "Neo Tshoma",
                Description = "Test Description xyz",
                Physical_Address = "1234 Daveyton 1520"
            },
            new CustomerModel
            {
                Id = 2,
                Code = "cust456",
                Name = "Tangent IT Solutions",
                Description = "A new Line of thinking a new kind of solution",
                Physical_Address = "57 Sloane Street, The Campus, Carisbrook Building, Bryanston"
            },
            new CustomerModel
            {
                Id = 3,
                Code = "cust789",
                Name = "Ekurhuleni Municipality",
                Description = "The Place of peace",
                Physical_Address = "1234 Kempton Park"
            }
        };

        public static readonly List<LeaveModel> LeaveData = new List<LeaveModel>
        {
            new LeaveModel
            {
                Id = 22,
                Employee = Employees.Find(employee => employee.User.Id == 100),
                Start_Date = "2019-01-15",
                End_Date = "2019-01-18",
                Status = "Approved",
                Half_Day = false,
                Type = "Annual",
                Upload = null,
                Leave_Days = "2.0"
            }
        };
    }
}
