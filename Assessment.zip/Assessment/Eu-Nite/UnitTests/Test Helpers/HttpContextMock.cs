﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace UnitTests.Test_Helpers
{
    public class HttpContextMock : ISession
    {
        Dictionary<string,object> sessionStorage = new Dictionary<string,object>();

        public object this[string sessionName]
        {
            get
            {
                return sessionStorage[sessionName];
            }
            set
            {
                sessionStorage[sessionName] = value;
            }
        }

        string ISession.Id
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        bool ISession.IsAvailable
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        IEnumerable<string> ISession.Keys
        {
            get
            {
                return sessionStorage.Keys;
            }
        }

        void ISession.Clear()
        {
            sessionStorage.Clear();
        }

        Task ISession.CommitAsync(System.Threading.CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        Task ISession.LoadAsync(System.Threading.CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        void ISession.Remove(string key)
        {
            sessionStorage.Remove(key);
        }

        void ISession.Set(string key, byte[] value)
        {
            sessionStorage[key] = key;
        }

        bool ISession.TryGetValue(string key, out byte[] value)
        {
            if (sessionStorage[key] != null)
            {
                value = Encoding.ASCII.GetBytes(sessionStorage[key].ToString());
                return true;
            }
            else
            {
                value = null;
                return false;
            }
        }

    }
}
