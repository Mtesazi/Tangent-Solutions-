﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace UnitTests.Test_Helpers
{
    //This class is used for testing
    public class HttpClientFactoryMessageHandler: DelegatingHandler
    {
        private HttpResponseMessage _requestResponse;

        public HttpClientFactoryMessageHandler(HttpResponseMessage requestResponse)
        {
            _requestResponse = requestResponse;
        }

        protected override async Task<HttpResponseMessage>SendAsync(HttpRequestMessage httpRequestMessage, CancellationToken cancellactionToken)
        {
            return await Task.FromResult(_requestResponse);
        }
    }
}
