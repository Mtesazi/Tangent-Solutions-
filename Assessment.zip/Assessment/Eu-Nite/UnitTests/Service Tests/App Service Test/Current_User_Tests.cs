﻿using Eu_Nite.Server.Controllers;
using Eu_Nite.Shared.Helpers;
using Eu_Nite.Shared.Models;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Moq;
using Newtonsoft.Json;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using UnitTests.Test_Helpers;
using Xunit;

namespace UnitTests.Service_Tests.App_Service_Test
{
    public class Current_User_Tests
    {
        private HttpContextMock sessionObject = new HttpContextMock();
        private Mock<HttpContext> httpContextMock = new Mock<HttpContext>();
        private HttpClientFactoryMessageHandler httpMessageHandler;
        private Eu_NiteController app_main_service;
        private TokenModel tokenModel;
        private HttpClient httpClient;

        [Fact]
        public void Current_User_ValidToken_Returns_CurrentUserDetails()
        {
            //Arrange
            var httpClientFactoryMock = Substitute.For<IHttpClientFactory>();
            tokenModel = new TokenModel() { Token = TestingConstants.token_value };
            var current_user = TestStubs.User;

            httpMessageHandler = new HttpClientFactoryMessageHandler(new HttpResponseMessage()
            {

                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(JsonConvert.SerializeObject(current_user), Encoding.UTF8, "application/json")
            });

            httpClient = new HttpClient(httpMessageHandler);
            httpClientFactoryMock.CreateClient().Returns(httpClient);

            sessionObject[Constants.session_key] = TestingConstants.token_value;
            httpContextMock.Setup(s => s.Session).Returns(sessionObject);

            app_main_service = new Eu_NiteController(httpClientFactoryMock);
            app_main_service.ControllerContext.HttpContext = httpContextMock.Object;
            
            //Act
            var results = app_main_service.Current_User().Result;


            //Assert
            results.Should().BeOfType<UserModel>().And.Equals(HttpStatusCode.OK);
        }

        [Fact]
        public void Current_User_InvalidToken_Returns_Null()
        {
            //Arrange
            var httpClientFactoryMock = Substitute.For<IHttpClientFactory>();
            tokenModel = new TokenModel() { Token = TestingConstants.invalid_token_value };

            httpMessageHandler = new HttpClientFactoryMessageHandler(new HttpResponseMessage()
            {

                StatusCode = HttpStatusCode.Unauthorized,
                Content = new StringContent(JsonConvert.SerializeObject(null), Encoding.UTF8, "application/json")
            });

            httpClient = new HttpClient(httpMessageHandler);
            httpClientFactoryMock.CreateClient().Returns(httpClient);

            sessionObject[Constants.session_key] = tokenModel.Token;
            httpContextMock.Setup(s => s.Session).Returns(sessionObject);

            app_main_service = new Eu_NiteController(httpClientFactoryMock);
            app_main_service.ControllerContext.HttpContext = httpContextMock.Object;

            //Act
            var results = app_main_service.Current_User().Result;

            //Assert
            results.Should().BeNull().And.Equals(HttpStatusCode.NoContent);
        }
    }

}
