﻿using Eu_Nite.Server.Controllers;
using Eu_Nite.Shared.Helpers;
using Eu_Nite.Shared.Models;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Moq;
using Newtonsoft.Json;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using UnitTests.Test_Helpers;
using Xunit;

namespace UnitTests.Service_Tests.App_Service_Test
{
    public class HttpResultSet_Tests
    {
        private HttpContextMock sessionObject = new HttpContextMock();
        private HttpClientFactoryMessageHandler httpMessageHandler;
        private Eu_NiteController app_main_service;
        private TokenModel tokenModel;
        private HttpClient httpClient;

        [Fact]
        public void HttpResultSet_ValidToken_Returns_Ok_Status()
        {
            //Arrange
            var httpClientFactoryMock = Substitute.For<IHttpClientFactory>();
            tokenModel = new TokenModel() { Token = TestingConstants.token_value };
            var leaveDetails = TestStubs.LeaveData;

            httpMessageHandler = new HttpClientFactoryMessageHandler(new HttpResponseMessage()
            {

                StatusCode = HttpStatusCode.OK
            });

            httpClient = new HttpClient(httpMessageHandler);
            httpClientFactoryMock.CreateClient().Returns(httpClient);

            app_main_service = new Eu_NiteController(httpClientFactoryMock);

            //Act
            var results = app_main_service.HttpResultSet(HttpMethod.Get, Constants.current_user_endpoint, tokenModel.Token).Result;

            //Assert
            results.Should().BeOfType<HttpResponseMessage>().And.Equals(HttpStatusCode.OK);
        }

        [Fact]
        public void HttpResultSet_InvalidToken_Returns_Null()
        {
            //Arrange
            var httpClientFactoryMock = Substitute.For<IHttpClientFactory>();
            tokenModel = new TokenModel() { Token = TestingConstants.invalid_token_value };

            httpMessageHandler = new HttpClientFactoryMessageHandler(new HttpResponseMessage()
            {

                StatusCode = HttpStatusCode.Unauthorized,
            });

            httpClient = new HttpClient(httpMessageHandler);
            httpClientFactoryMock.CreateClient().Returns(httpClient);

            app_main_service = new Eu_NiteController(httpClientFactoryMock);

            //Act
            var results = app_main_service.HttpResultSet(HttpMethod.Get, Constants.current_user_endpoint, tokenModel.Token).Result;

            //Assert
            results.Should().BeNull().And.Equals(HttpStatusCode.NoContent);
        }

        [Fact]
        public void HttpResultSet_EmptyToken_Returns_Null()
        {
            //Arrange
            var httpClientFactoryMock = Substitute.For<IHttpClientFactory>();
            tokenModel = new TokenModel() { Token = String.Empty};

            httpMessageHandler = new HttpClientFactoryMessageHandler(new HttpResponseMessage()
            {

                StatusCode = HttpStatusCode.OK,
            });

            httpClient = new HttpClient(httpMessageHandler);
            httpClientFactoryMock.CreateClient().Returns(httpClient);

            app_main_service = new Eu_NiteController(httpClientFactoryMock);

            //Act
            var results = app_main_service.HttpResultSet(HttpMethod.Get, Constants.current_user_endpoint, tokenModel.Token).Result;

            //Assert
            results.Should().BeNull().And.Equals(HttpStatusCode.NoContent);
        }
    }
}
