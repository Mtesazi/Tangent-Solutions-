﻿using Eu_Nite.Server.Controllers;
using Eu_Nite.Shared.Helpers;
using Eu_Nite.Shared.Models;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Moq;
using Newtonsoft.Json;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using UnitTests.Test_Helpers;
using Xunit;

namespace UnitTests.Service_Tests.Auth_Tests
{
    public class Logout_Tests
    {
        private AuthController auth_service;
        private HttpContextMock sessionObject = new HttpContextMock();
        private Mock<HttpContext> httpContextMock = new Mock<HttpContext>();
        private HttpClientFactoryMessageHandler httpMessageHandler;
        private HttpClient httpClient;
        private TokenModel tokenModel;

        [Fact]
        public void Logout_Clears_Session()
        {
            //Arrange
            var httpClientFactoryMock = Substitute.For<IHttpClientFactory>();
            tokenModel = new TokenModel() { Token = TestingConstants.token_value };

            httpMessageHandler = new HttpClientFactoryMessageHandler(new HttpResponseMessage()
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(String.Empty)
            });

            httpClient = new HttpClient(httpMessageHandler);
            httpClientFactoryMock.CreateClient().Returns(httpClient);

            sessionObject[Constants.session_key] = tokenModel.Token;
            httpContextMock.Setup(s => s.Session).Returns(sessionObject);

            auth_service = new AuthController(httpClientFactoryMock);
            auth_service.ControllerContext.HttpContext = httpContextMock.Object;

            var result = auth_service.Logout();

            auth_service.ControllerContext.HttpContext.Should().Equals(String.Empty);
        }
    }
}
