﻿using Eu_Nite.Server.Controllers;
using Eu_Nite.Shared.Helpers;
using Eu_Nite.Shared.Models;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Moq;
using Newtonsoft.Json;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using UnitTests.Test_Helpers;
using Xunit;


namespace UnitTests.Service_Tests.Login
{
    public class Login_Tests
    {
        private HttpContextMock sessionObject = new HttpContextMock();
        private Mock<HttpContext> httpContextMock = new Mock<HttpContext>();
        private HttpClientFactoryMessageHandler httpMessageHandler;
        private AuthController auth_service;
        private TokenModel tokenModel;
        private HttpClient httpClient;

        [Fact]
        public void Login_CorrectCredentials_Returns_OK()
        {
            //Arrange
            var httpClientFactoryMock = Substitute.For<IHttpClientFactory>();
            tokenModel = new TokenModel() { Token = TestingConstants.token_value }; //The fake token value that will be returned by the mocked request

            httpMessageHandler = new HttpClientFactoryMessageHandler(new HttpResponseMessage()
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(JsonConvert.SerializeObject(tokenModel), Encoding.UTF8, "application/json")
            });
            
            //correct username and password
            var loginData = new LoginModel() { UserName = "pravin.gordhan", Password = "pravin.gordhan" };

            httpClient = new HttpClient(httpMessageHandler);
            httpClientFactoryMock.CreateClient().Returns(httpClient);

            //the representation of the session object
            sessionObject[Constants.session_key] = tokenModel.Token;
            httpContextMock.Setup(s => s.Session).Returns(sessionObject);

            auth_service = new AuthController(httpClientFactoryMock);
            auth_service.ControllerContext.HttpContext = httpContextMock.Object;

            //Act 
            var result = auth_service.Login(loginData).Result;

            //Assert
            result.Should().Equals(HttpStatusCode.OK);

        }

        [Fact]
        public void Login_IncorrectCredentials_Returns_Unauthorized()
        {
            //Arrange
            var httpclientFactoryMock = Substitute.For<IHttpClientFactory>();
            httpMessageHandler = new HttpClientFactoryMessageHandler(new HttpResponseMessage()
            {
                StatusCode = HttpStatusCode.Unauthorized,
                Content = null
            });

            //incorrect username and password
            var loginData = new LoginModel() { UserName = "super.man", Password = "bat.man" };

            httpClient = new HttpClient(httpMessageHandler);
            httpclientFactoryMock.CreateClient().Returns(httpClient);

            auth_service = new AuthController(httpclientFactoryMock);

            //Act
            var result = auth_service.Login(loginData).Result;

            //Assert
            result.Should().Equals(HttpStatusCode.Unauthorized);
        }
    }
}
