﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Eu_Nite.Shared.Helpers{
    public class Constants
    {
        //base url for all the services
        public static string base_url = "http://staging.tangent.tngnt.co/";

        //service end points
        public static string auth_endpoint = "/api-token-auth/";
        public static string current_user_endpoint = "/api/user/me/";
        public static string employee_endpoint = "/api/employee/";
        public static string profile_endpoint = "/api/employee/me/";
        public static string review_endpoint = "/api/review/";
        public static string customers_endpoint = "/api/customer/";
        public static string leave_endpoint = "/api/leave/";

        //Name used when registering an Http Client name for Dependency Injection
        public static string httpClient_name = "Tangent_Solutions";

        //The name of the key that is used to access the token stored in the session
        public static string session_key = "Tangent_Token";


        //endpoints to the asp.net core api that I built
        public static string eu_nite_auth_endpoint = "eu-nite/Auth/Login";
        public static string eu_nite_employee_endpoint = "eu-nite/Employees";
        public static string eu_nite_reviews_endpoint = "eu-nite/Reviews";
        public static string eu_nite_profile_endpoint = "eu-nite/Profile";
        public static string eu_nite_customers_endpoint = "eu-nite/Customers";
        public static string eu_nite_leave_details = "eu-nite/Leave_Details";
        public static string eu_nite_logout = "eu-nite/Auth/Logout";
    }
}
