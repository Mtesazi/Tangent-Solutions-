﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Eu_Nite.Shared.Models
{
    public class ReviewModel
    {
        public int Id { get; set; }

        public string Date { get; set; }

        public string Salary { get; set; }

        public string Type { get; set; }

        public int Employee { get; set; }

        public int Position { get; set; }
    }
}
