﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Eu_Nite.Shared.Models
{
    public class StatisticsModel
    {
        public int Birthdays { get; set; }
        public int TotalEmployeeCount { get; set; }
        public int FemaleEmployees { get; set; }
        public int MaleEmployees { get; set; }
        public int JuniorPositions { get; set; }
        public int SeniorPositions { get; set; }
        public int AfricanEmployees { get; set; }
        public int ColouredEmployees { get; set; }
        public int WhiteEmployees { get; set; }
        public int IndianOrAsianEmployees { get; set; }
        public int NonDominantEmployees { get; set; }
    }
}
