﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Eu_Nite.Shared.Models
{
    public class LeaveModel
    {
        public int Id { get; set; }

        public EmployeeModel Employee { get; set; }

        public string Start_Date { get; set; }

        public string End_Date { get; set; }

        public string Status { get; set; }

        public bool Half_Day { get; set; }

        public string Type { get; set; }

        public string Upload { get; set; }

        public string Leave_Days { get; set; }
    }
}
