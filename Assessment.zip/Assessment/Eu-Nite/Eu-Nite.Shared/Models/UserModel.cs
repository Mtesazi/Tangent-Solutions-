﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Eu_Nite.Shared.Models
{
    public class UserModel
    {
        public int Id { get; set; }

        public string UserName { get; set; }

        public string Email { get; set; }

        public string First_Name { get; set; }

        public string Last_Name { get; set; }

        public bool Is_Active { get; set; }

        public bool Is_Staff { get; set; }

        public bool Is_SuperUser { get; set; }
    }
}
