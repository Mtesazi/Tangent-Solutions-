﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Eu_Nite.Shared.Models
{
    public class EmployeeModel
    {
        public UserModel User { get; set; }

        public PositionModel Position { get; set; }

        public string Phone_Number { get; set; }

        public string Email { get; set; }

        public string Github_User { get; set; }

        public string Birth_Date { get; set; }

        public string Gender { get; set; }

        public string Race { get; set; }

        public int Years_Worked { get; set; }

        public int Age { get; set; }

        public int Days_To_Birthday { get; set; }
    }
}
