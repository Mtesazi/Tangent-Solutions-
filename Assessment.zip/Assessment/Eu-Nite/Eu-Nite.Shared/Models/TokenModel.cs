﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Eu_Nite.Shared.Models
{
    public class TokenModel
    {
        public string Token { get; set; }
    }
}
