﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Eu_Nite.Shared.Models
{
    public class ProfileModel
    {
        public int Id { get; set; }

        public UserModel User { get; set; }

        public PositionModel Position { get; set; }

        public List<NextOfKinModel> Employee_Next_Of_Kin { get; set; }

        public List<ReviewModel> Employee_Review { get; set; }

        public string Id_Number { get; set; }

        public string Phone_Number { get; set; }

        public string Physical_Address { get; set; }

        public string Tax_Number { get; set; }

        public string Email { get; set; }

        public string Personal_Email { get; set; }

        public string Github_User { get; set; }

        public string Birth_Date { get; set; }

        public string Start_Date { get; set; }

        public string End_Date { get; set; }

        public string Id_Document { get; set; }

        public string Visa_Document { get; set; }

        public bool Is_Employed { get; set; }

        public bool Is_Foreigner { get; set; }

        public string Gender { get; set; }

        public string Race { get; set; }

        public int Years_Worked { get; set; }

        public int Age { get; set; }

        public string Next_Review { get; set; }

        public int Days_To_Birthday { get; set; }

        public string Leave_Remaining { get; set; }
    }
}
