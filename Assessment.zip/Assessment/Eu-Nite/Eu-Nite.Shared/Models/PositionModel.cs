﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Eu_Nite.Shared.Models
{
    public class PositionModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Level { get; set; }

        public int Sort { get; set; }
    }
}
