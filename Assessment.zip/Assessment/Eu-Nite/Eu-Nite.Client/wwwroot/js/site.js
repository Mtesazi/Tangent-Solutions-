﻿function responsiveNavigation() {
    $(".sidenav").sidenav();
}
function loadDataTable() {
    $("#employeesTable").DataTable({
        ordering: true,
        responsive: true
    });
}